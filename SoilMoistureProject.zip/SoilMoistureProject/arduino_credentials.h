#define MY_SSID "jermas house"
#define MY_PASS "JeremyElbertson985"

#define CH_ID 2504726
#define WRITE_APIKEY "2EP4L2TKTSZAMX4Z"
